package mainlibrary;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

// Custom class created to provide improved error logging.
public class ErrorLogger {

    // Get a logger instance.
    private static final Logger LOGGER = Logger.getLogger(ErrorLogger.class.getName());

    // Static block for one-time setup configuration.
    static {
        try {
            LOGGER.setUseParentHandlers(false);

            // Creates and configure a FileHandler to write logs to a file "library_errors.log".
            FileHandler fileHandler = new FileHandler("library_errors.log", true);

            // Uses a simple text formatter for the log file.
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
 
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error occurred in FileHandler setup.", e);
            // Sets further error handling if logger setup fails.
            System.err.println("CRITICAL: Failed to initialize file logger.");
        
        } catch (SecurityException e) {
             LOGGER.log(Level.SEVERE, "Security error occurred during FileHandler setup.", e);
             System.err.println("CRITICAL: Security error initializing file logger.");
        }
    }

    /**
     * Logs a message with an associated Throwable (like an exception).
     *
     * @param level The logging level (e.g., Level.SEVERE, Level.WARNING, Level.INFO).
     * @param msg   The message string to log.
     * @param thrown The Throwable (exception) to log, including its stack trace.
     */
    public static void log(Level level, String msg, Throwable thrown) {
        LOGGER.log(level, msg, thrown);
    }

    /**
     * Logs a simple message without a Throwable.
     *
     * @param level The logging level.
     * @param msg   The message string to log.
     */
    public static void log(Level level, String msg) {
        LOGGER.log(level, msg);
    }

    // You can add more specific methods if needed, e.g., logSevere, logWarning etc.
    public static void logSevere(String msg, Throwable thrown) {
        log(Level.SEVERE, msg, thrown);
    }

     public static void logWarning(String msg) {
        log(Level.WARNING, msg);
    }

}
