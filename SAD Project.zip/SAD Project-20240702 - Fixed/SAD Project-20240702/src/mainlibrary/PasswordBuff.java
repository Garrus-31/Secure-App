package mainlibrary;

import org.mindrot.jbcrypt.BCrypt;

// Custom class created to improve password security.

public class PasswordBuff {

    // Method created to hash passwords using BCrypt with a generated salt.
    public static String hashedPassword(String plainTextPassword){
        if (plainTextPassword == null || plainTextPassword.isEmpty()) {
        
            return null;
        }
        // BCrypt.hashpw incorporates salt into the resulting hash string.
        return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
    }

    // Method to check a provided password against a stored BCrypt hash
    public static boolean checkPassword(String plainTextPassword, String hashedPassword) {
        if (plainTextPassword == null || hashedPassword == null || hashedPassword.isEmpty()) {
            return false;
        }
        try {
            // BCrypt.checkpw automatically extracts the salt from hashedPassword and compares the hash of plainPassword (using that salt) to the stored hash.
            return BCrypt.checkpw(plainTextPassword, hashedPassword);
        } catch (IllegalArgumentException e) 
        {
            System.err.println("Error checking password: Invalid hash format - " + e.getMessage());
        } 
        return false;
    }
}